# FDU-Beamer-Theme

- forked from [thu beamer theme](https://github.com/Trinkle23897/THU-Beamer-Theme) 2021/4/13

- two color theme: [fdu_blue](FDU_Beamer_Theme_blue.pdf) and [fdu_red](FDU_Beamer_Theme_red.pdf)

- You can click the icon to open the template in overleaf. [![Open In Overleaf](https://badgen.net/badge/%20/Open%20In%20%20Overleaf/green?icon=https://images.ctfassets.net/nrgyaltdicpt/2nBkkfg5vkAEOmdJOb1BkZ/61b5fb98c52d1be763426ee58f36bc6e/ologo_square_bw.svg)](https://www.overleaf.com/latex/templates/fdu-beamer-theme/vjhpmpndbqtc)
***

最初能追溯到的版本是 [https://www.latexstudio.net/archives/4051.html](https://www.latexstudio.net/archives/4051.html)

我在16年的时候魔改了一发，20年的时候小修了一下，变成现在这样

Overleaf模板位于：[https://www.overleaf.com/latex/templates/thu-beamer-theme/vwnqmzndvwyb](https://www.overleaf.com/latex/templates/thu-beamer-theme/vwnqmzndvwyb)，可以直接点开

其中的教程部分参考了大鹰团长的介绍：[https://tuna.moe/event/2018/latex/](https://tuna.moe/event/2018/latex/)
